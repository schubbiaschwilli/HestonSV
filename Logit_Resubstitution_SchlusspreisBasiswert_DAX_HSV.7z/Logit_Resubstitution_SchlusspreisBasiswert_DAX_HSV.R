library(pROC)
library(pscl)
library(caret)
library(MASS)

# Load data
load(file="HestonSV_Results_All_julia.rdata")
data <- HestonSVResults_All_julia[, c("Handelstag", "SchlusspreisBasiswert", "EONIA", "v0", "vT", "rho", "k", "sigma", "RSS")]

# Create Target / Move Target 1 day forward
data$SchlusspreisBasiswert_Target <- as.integer((sign(c(diff(data$SchlusspreisBasiswert), NA))+1)/2)

# Create Model 1 / Resubstitution / Plot
Model1 <- glm(SchlusspreisBasiswert_Target ~., family=binomial(link='logit'), data=data)
pred <- predict(Model1, newdata=data, type="response")
ROC <- roc(response=as.double(data$SchlusspreisBasiswert_Target), predictor=as.double(pred))
title <- paste("Area under curve : ", format(ROC$auc, digits=3), sep='')
plot.roc(as.double(data$SchlusspreisBasiswert_Target), as.double(pred), main=title)

# Add Delta
data$SchlusspreisBasiswert_Delta <- c(NA, diff(data$SchlusspreisBasiswert))
data$EONIA_Delta <- c(NA, diff(data$EONIA))
data$RSS_Delta <- c(NA, diff(data$RSS))
data$v0_Delta <- c(NA, diff(data$v0))
data$vT_Delta <- c(NA, diff(data$vT))
data$rho_Delta <- c(NA, diff(data$rho))
data$k_Delta <- c(NA, diff(data$k))
data$sigma_Delta <- c(NA, diff(data$sigma))
data <- data[-1,]

# Create Model 2 / Resubstitution / Plot
Model2 <- glm(SchlusspreisBasiswert_Target ~., family=binomial(link='logit'), data=data)

pred <- predict(Model2, newdata=data, type="response")
ROC <- roc(response=as.double(data$SchlusspreisBasiswert_Target), predictor=as.double(pred))
title <- paste("Area under curve : ", format(ROC$auc, digits=3), sep='')
plot.roc(as.double(data$SchlusspreisBasiswert_Target), as.double(pred), main=title)

# Add more data
cols <- c("v0", "vT", "rho", "k", "sigma", "RSS", "RSS_Delta", "v0_Delta", "vT_Delta", "rho_Delta", "k_Delta", "sigma_Delta")
for (i in 1:(length(cols))){
  for (j in i:length(cols)){
    col_new <- paste(cols[i], "_x_", cols[j], sep="")
    data[col_new] <- data[cols[i]] * data[cols[j]]
  }   
}

# Create Model 3 / Resubstitution / Plot / Pseudo-R-squared / Table
Model3 <- glm(SchlusspreisBasiswert_Target ~., family=binomial(link='logit'), data=data)
pred <- predict(Model3, newdata=data, type="response")
ROC <- roc(response=as.double(data$SchlusspreisBasiswert_Target), predictor=as.double(pred))
title <- paste("Area under curve : ", format(ROC$auc, digits=3), sep='')
plot.roc(as.double(data$SchlusspreisBasiswert_Target), as.double(pred), main=title)
pR2(Model3)
confusionMatrix(as.factor(ifelse(as.double(pred)>0.5,1,0)), as.factor(data$SchlusspreisBasiswert_Target))

# Create Model 3 AIC / Resubstitution / Plot / Pseudo-R-squared / Table
Model3_AIC <- stepAIC(Model3, direction="both")
summary(Model3_AIC)
pred <- predict(Model3_AIC, newdata=data, type="response")
ROC <- roc(response=as.double(data$SchlusspreisBasiswert_Target), predictor=as.double(pred))
title <- paste("Area under curve : ", format(ROC$auc, digits=3), sep='')
plot.roc(as.double(data$SchlusspreisBasiswert_Target), as.double(pred), main=title)
pR2(Model3_AIC)
confusionMatrix(as.factor(ifelse(as.double(pred)>0.5,1,0)), as.factor(data$SchlusspreisBasiswert_Target))
