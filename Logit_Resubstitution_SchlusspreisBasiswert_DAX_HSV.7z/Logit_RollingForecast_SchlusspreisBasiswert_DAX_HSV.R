# Load & create data
load(file="HestonSV_Results_All_julia.rdata")
data <- HestonSVResults_All_julia[, c("Handelstag", "SchlusspreisBasiswert", "EONIA", "v0", "vT", "rho", "k", "sigma", "RSS")]
data$SchlusspreisBasiswert_Target <- as.integer((sign(c(diff(data$SchlusspreisBasiswert), NA))+1)/2)

# Add Delta
data$SchlusspreisBasiswert_Delta <- c(NA, diff(data$SchlusspreisBasiswert))
data$EONIA_Delta <- c(NA, diff(data$EONIA))
data$RSS_Delta <- c(NA, diff(data$RSS))
data$v0_Delta <- c(NA, diff(data$v0))
data$vT_Delta <- c(NA, diff(data$vT))
data$rho_Delta <- c(NA, diff(data$rho))
data$k_Delta <- c(NA, diff(data$k))
data$sigma_Delta <- c(NA, diff(data$sigma))
data <- data[-1,]

# Add more data
cols <- c("v0", "vT", "rho", "k", "sigma", "RSS", "RSS_Delta", "v0_Delta", "vT_Delta", "rho_Delta", "k_Delta", "sigma_Delta")
for (i in 1:(length(cols))){
  for (j in i:length(cols)){
    col_new <- paste(cols[i], "_x_", cols[j], sep="")
    data[col_new] <- data[cols[i]] * data[cols[j]]
  }   
}

GetTrainingDays <- function(Handelstag_From, Handelstag_To, Handelstage_Data){
  return(subset(Handelstage_Data, Handelstag>=as.POSIXct(Handelstag_From, tz="UTC") & Handelstag<=as.POSIXct(Handelstag_To, tz="UTC"))[,-1])
}

GetTestDay <- function(Handelstag, Handelstage_Data){
  return(GetTrainingDays(Handelstag, Handelstag, Handelstage_Data))
}

GetResults <- function(TrainingDays_, results){
  return(subset(results, TrainingDays==TrainingDays_)[, c("PCs", "SchlusspreisBasiswert_Target")])
}

# Create dataframe for results
TrainingDays <- 119

results <- data.frame(Training_Handelstag_From=data$Handelstag[c(1:(nrow(data)-TrainingDays))],
                        Training_Handelstag_To=data$Handelstag[c(TrainingDays:(nrow(data)-1))],
                        Forecast=data$Handelstag[c((TrainingDays+1):nrow(data))],
                        TrainingDays=rep(TrainingDays, nrow(data)-TrainingDays))
results[, "PCs"] <- -1
results[, "SchlusspreisBasiswert_Target"] <- -1
  
for(i in 1:nrow(results)){
  # Get data
  TrainingsData <- GetTrainingDays(results[i, "Training_Handelstag_From"], results[i, "Training_Handelstag_To"], data)
  TestDay <- GetTestDay(results[i, "Forecast"], data)

  # Build model
  Model <- glm(SchlusspreisBasiswert_Target ~., family=binomial(link="logit"), data=TrainingsData, maxit=10000)
  pred <- predict(Model, newdata=TestDay, type="response")
  results[i, "PCs"] <- pred
  results[i, "SchlusspreisBasiswert_Target"] <- TestDay$SchlusspreisBasiswert_Target
}

# Create ROC-Chart
library(pROC)
ROC <- roc(response=results$SchlusspreisBasiswert_Target, predictor=results$PCs, quiet=TRUE)
title <- paste(TrainingDays, " TrainingDays; Area under curve : ", format(ROC$auc, digits=3), sep='')
plot.roc(as.double(results$SchlusspreisBasiswert_Target), as.double(results$PCs), main=title)

# Create table
library(caret)
confusionMatrix(as.factor(ifelse(as.double(results$PCs)>0.5,1,0)), as.factor(results$SchlusspreisBasiswert_Target))
