import numpy as np
import pandas as pd
from statistics import mean

def HestonSV_MC(S,T, r, q, v0, theta, rho, kappa, sigma, NPaths, Seed=1234567):
    np.random.seed(Seed)
    St = np.array([0.0] * NPaths)
    NSteps = int(np.floor(T*252))
    dt = T/NSteps
    
    for j in range(0, NPaths):
        S_t = S
        v_t = v0
        for i in range(0, NSteps+1):
            Wt1 = np.random.normal(loc=0, scale=1.0)
            Wt2 = rho * Wt1 + np.sqrt(1.0 - rho**2) * np.random.normal(loc=0, scale=1.0)
            S_t = S_t*np.exp((r - q - v_t/2)*dt + np.sqrt(v_t*dt)*Wt1)
            dt_vt = kappa*(theta-v_t)*dt + sigma*np.sqrt(v_t*dt)*Wt2
            v_t = v_t + dt_vt
            
            if v_t <= 0:
                v_t = v_t - 2*dt_vt  
            
        St[j] = S_t
    return St 

r = 0.01
T = 1

St = HestonSV_MC(S=100,T=T,r=r,q=0.02,v0=0.04,theta=0.25,rho=-0.5,kappa=4.0,sigma=1.0,NPaths=10**6)
TSEnd = datetime.now()

Results = pd.DataFrame(list(range(80, 130, 10)), columns=['Strike'])
Results['PriceCall'] = np.nan
Results['PricePut'] = np.nan

for i in range(0, len(Results)):
    Results['PriceCall'].values[i] = np.exp(-r*T)*mean(np.maximum(St - Results['Strike'].values[i],0))
    Results['PricePut'].values[i] = np.exp(-r*T)*mean(np.maximum(Results['Strike'].values[i] - St,0))

print(Results)
