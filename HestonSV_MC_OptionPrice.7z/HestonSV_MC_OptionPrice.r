HestonSV_MC <- function(S,T,r,q,v0,theta,rho,kappa,sigma,NPaths,seed=606060){
	set.seed(seed)

	NSteps <- floor(T*252)
	Results <- rep(0, NPaths)
	dt <- T/NSteps
	
	for(Path in 1:(NPaths)){
		St <- S  # Stock price
		vt <- v0 # Volatility

	for(Step in 1:NSteps){
		Wt1 <- rnorm(1)
		Wt2 <- rho * Wt1 + sqrt(1 - rho^2) * rnorm(1)
		
		St <- St*exp((r - q - vt/2)*dt + sqrt(vt*dt)*Wt1)

		dt_vt <- kappa*(theta-vt)*dt + sigma*sqrt(vt*dt)*Wt2
		vt <- vt + dt_vt
		
		if(vt <= 0) vt <- vt - 2*dt_vt
	}
	Results[Path] <- St
	}

	return(Results)
}

r <- 0.01
T <- 1

St <- HestonSV_MC(S=100,T=T,r,q=0.02,v0=0.04,theta=0.25,rho=-0.5,kappa=4.0,sigma=1.0,NPaths=10^6)

Results <- data.frame(Strike=seq(80,120,10))
Results$PriceCall <- NA
Results$PricePut <- NA

for(i in 1:nrow(Values)){
	Results$PriceCall[i] <- exp(-r*T)*mean(pmax(St - Values$Strike[i], 0))
	Results$PricePut[i] <- exp(-r*T)*mean(pmax(Values$Strike[i] - St, 0))
}

print(Results)