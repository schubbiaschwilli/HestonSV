using DataFrames
using Random

function HestonSV_MC(;S,T,r,q,v0,theta,rho,kappa,sigma,NPaths,Seed=3141592)
  Random.seed!(Seed)
  
  NSteps = floor(T*252)
  Results = zeros(NPaths)
  dt = T/NSteps

  for Path = 1:NPaths
    St = S  # Stock price
    vt = v0 # Volatility

    for Step = 1:NSteps
      Wt1 = randn(1)[1]
      Wt2 = rho * Wt1 + sqrt(1 - rho^2) * randn(1)[1]
      St = St*exp((r - q - vt/2)*dt + sqrt(vt*dt)*Wt1)
      dt_vt = kappa*(theta-vt)*dt + sigma*sqrt(vt*dt)*Wt2
      vt = vt + dt_vt
      
      if vt <= 0
        vt = vt - 2*dt_vt  
      end
      Results[Path] = St
    end
  end
  return(Results)
end

r = 0.01
T = 1

St = HestonSV_MC(S=100,T=T,r=r,q=0.02,v0=0.04,theta=0.25,rho=-0.5,kappa=4.0,sigma=1.0,NPaths=10^6)

Results = DataFrame(Strike = [80:10:120;])
Results[!,:Call] .= 0.0
Results[!,:Put] .= 0.0

for i = 1:size(Results)[1]
  # Call
  PayOffs = St .- Results[i,:Strike]
  Results[i,:Call] = exp(-r*T)*sum(PayOffs[findall(PayOffs .>= 0)])/size(St)[1]
  
  # Put
  PayOffs = Results[i,:Strike] .- St
  Results[i,:Put] = exp(-r*T)*sum(PayOffs[findall(PayOffs .>= 0)])/size(St)[1]
end

print(Results)
