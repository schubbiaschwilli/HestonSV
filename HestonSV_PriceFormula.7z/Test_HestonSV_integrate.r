callHestoncf <- function(S, X, tau, r, q, v0, vT, rho, k, sigma){
	P1 <- function(om,S,X,tau,r,q,v0,vT,rho,k,sigma){
		return(Re(exp(-1i * log(X) * om) * cfHeston(om - 1i,S,tau,r,q,v0,vT,rho,k,sigma) / (1i * om * S * exp((r-q) * tau))))
	}
	P2 <- function(om,S,X,tau,r,q,v0,vT,rho,k,sigma){
		return(Re(exp(-1i * log(X) * om) * cfHeston(om,S,tau,r,q,v0,vT,rho,k,sigma) / (1i * om)))
	}

	cfHeston <- function(om,S,tau,r,q,v0,vT,rho,k,sigma){
		d <- sqrt((rho * sigma * 1i * om - k)^2 + sigma^2 * (1i * om + om ^ 2))
		g <- (k - rho * sigma * 1i * om - d) / (k - rho * sigma * 1i * om + d)
		cf1 <- 1i * om * (log(S) + (r - q) * tau)
		cf2 <- vT*k/(sigma^2)*((k - rho * sigma * 1i * om - d) * tau - 2 * log((1 - g * exp(-d * tau)) / (1 - g)))
		cf3 <- v0 / sigma^2 * (k - rho * sigma * 1i * om - d) * (1 - exp(-d * tau)) / (1 - g * exp(-d * tau))
		return(exp(cf1 + cf2 + cf3))
	}

	tryCatch({
		vP1 <- 0.5 + 1/pi * integrate(P1, lower = 0, upper = Inf, S, X, tau, r, q, v0, vT, rho, k, sigma)$value
		vP2 <- 0.5 + 1/pi * integrate(P2, lower = 0, upper = Inf, S, X, tau, r, q, v0, vT, rho, k, sigma)$value
		return(exp(-q * tau) * S * vP1 - exp(-r * tau) * X * vP2)
		}, error=function(error_message){
      message(error_message)
      return(NA)
    }
  )
}

# Load data
# setwd(...)
data <- read.csv("HestonSV_TestData.csv", stringsAsFactors=FALSE)

data$HestonSVPrice <- -1

for(i in 1:nrow(data)){  
	data[i, "HestonSVPrice"] <- callHestoncf(S=data[i,"S0"], X=data[i,"StrikePrice"], tau=data[i,"T"], r=data[i,"r"], q=data[i,"q"], v0=data[i,"v0"], vT=data[i,"vT"], rho=data[i,"rho"], k=data[i,"k"], sigma=data[i,"sigma"])
}
