import math
import cmath
import numpy as np
from scipy.integrate import quad
import csv
import pandas as pd

def P1(om,S,X,tau,r,q,v0,vT,rho,k,sigma):
    return (cmath.exp(-1j * math.log(X) * om) * cfHeston(om - 1j,S,tau,r,q,v0,vT,rho,k,sigma) / (1j * om * S * math.exp((r-q) * tau))).real

def P2(om,S,X,tau,r,q,v0,vT,rho,k,sigma):
    return (cmath.exp(-1j * math.log(X) * om) * cfHeston(om,S,tau,r,q,v0,vT,rho,k,sigma) / (1j * om)).real

def cfHeston(om,S,tau,r,q,v0,vT,rho,k,sigma):
    d = cmath.sqrt((rho * sigma * 1j * om - k)**2 + sigma**2 * (1j * om + om**2))
    g = (k - rho * sigma * 1j * om - d) / (k - rho * sigma * 1j * om + d)
    cf1 = 1j * om * (math.log(S) + (r - q) * tau)
    cf2 = vT*k/(sigma**2) * ((k - rho * sigma * 1j * om - d) * tau - 2 * cmath.log((1 - g * cmath.exp(-d * tau)) / (1 - g)))
    cf3 = v0 / (sigma**2) * (k - rho * sigma * 1j * om - d) * (1 - cmath.exp(-d * tau)) / (1 - g * cmath.exp(-d * tau))
    return cmath.exp(cf1 + cf2 + cf3)

def callHestoncf(S, X, tau, r, q, v0, vT, rho, k, sigma):
    try:
        Integral_P1, err = quad(P1,0,np.inf,args=(S,X,tau,r,q,v0,vT,rho,k,sigma,))
        Integral_P2, err = quad(P2,0,np.inf,args=(S,X,tau,r,q,v0,vT,rho,k,sigma,))
        return math.exp(-q * tau) * S * (0.5 + 1/math.pi * Integral_P1) - math.exp(-r * tau) * X * (0.5 + 1/math.pi * Integral_P2)
    except:
        return np.nan

# Load data
MarketData = pd.read_csv('HestonSV_TestData.csv', delimiter=',')

MarketData['HestonSVPrice'] = np.nan

for i in range(len(MarketData)):
    MarketData['HestonSVPrice'].values[i] = callHestoncf(MarketData['S0'].values[i], MarketData['StrikePrice'].values[i], MarketData['T'].values[i], MarketData['r'].values[i], MarketData['q'].values[i], MarketData['v0'].values[i], MarketData['vT'].values[i], MarketData['rho'].values[i], MarketData['k'].values[i], MarketData['sigma'].values[i])
