using QuadGK
using CSV
using DataFrames
using Dates

function P1(om,S,X,tau,r,q,v0,vT,rho,k,sigma)   
	# function P1(om,S,X,tau,r,q,v0,vT,rho,k,sigma)
	return real(exp(-1im * log(X) * om) * cfHeston(om - 1im,S,tau,r,q,v0,vT,rho,k,sigma) / (1im * om * S * exp((r-q) * tau)))
end

function P2(om,S,X,tau,r,q,v0,vT,rho,k,sigma)
	# function P2(om,S,X,tau,r,q,v0,vT,rho,k,sigma)
	return real(exp(-1im * log(X) * om) * cfHeston(om,S,tau,r,q,v0,vT,rho,k,sigma) / (1im * om))
end

function cfHeston(om,S,tau,r,q,v0,vT,rho,k,sigma)
	d = sqrt((rho * sigma * 1im * om - k)^2 + sigma^2 * (1im * om + om ^ 2))
	g = (k - rho * sigma * 1im * om - d) / (k - rho * sigma * 1im * om + d)
	cf1 = 1im * om * (log(S) + (r - q) * tau)
	cf2 = vT*k/(sigma^2)*((k - rho * sigma * 1im * om - d) * tau - 2 * log((1 - g * exp(-d * tau)) / (1 - g)))
	cf3 = v0 / sigma^2 * (k - rho * sigma * 1im * om - d) * (1 - exp(-d * tau)) / (1 - g * exp(-d * tau))
	return exp(cf1 + cf2 + cf3)
end

function callHestoncf(;S, X, tau, r, q, v0, vT, rho, k, sigma)
	try
		Integral_P1 = quadgk(om -> P1(om,S,X,tau,r,q,v0,vT,rho,k,sigma),0,Inf)[1]
		Integral_P2 = quadgk(om -> P2(om,S,X,tau,r,q,v0,vT,rho,k,sigma),0,Inf)[1]
		vP1 = 0.5 + 1/pi * Integral_P1
		vP2 = 0.5 + 1/pi * Integral_P2
		return exp(-q * tau) * S * vP1 - exp(-r * tau) * X * vP2
	catch
		return NaN
	end
end

# Load data
data = CSV.read("HestonSV_TestData.csv", DataFrame)

data[!,:HestonSVPrice] .= NaN

for i = 1:nrow(data)
	data[i,:HestonSVPrice] = callHestoncf(S=data[i,:S0], X=data[i,:StrikePrice], tau=data[i,:T], r=data[i,:r], q=data[i,:q], v0=data[i,:v0], vT=data[i,:vT], rho=data[i,:rho], k=data[i,:k], sigma=data[i,:sigma])
end
