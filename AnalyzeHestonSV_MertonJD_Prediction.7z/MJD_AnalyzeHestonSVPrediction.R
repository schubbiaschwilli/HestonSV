setwd(dirname(rstudioapi::getSourceEditorContext()$path))

### Load & Data cleansing
	load("EurexOptionsDaxMJDParameterResults.RData")

### Plot Parameter Jun 2016 over time w Line
	png("ParameterOverTime_Jun2016.png", width=1200, height=800, pointsize=20)
	
	colors=c("red","purple","turquoise")
	Dates <- as.POSIXct("2016-06-23", format="%Y-%m-%d")
	PreviousDates <- MertonJDResults[max(as.integer(row.names(subset(MertonJDResults, Handelstag<Dates, select=Handelstag)))), "Handelstag"]
	MertonJDResults_Jun2016 <- subset(MertonJDResults, format(MertonJDResults$Handelstag, "%m")=="06")
	
	par(mfrow=c(4,1), mar=c(2, 2, 0.5, 0.1))
	plot(y=MertonJDResults_Jun2016$sigma, x=MertonJDResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='black')
	legend("bottomleft", "sigma", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	plot(y=MertonJDResults_Jun2016$lambda, x=MertonJDResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='green')
	legend("topleft", "lambda", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	plot(y=MertonJDResults_Jun2016$m, x=MertonJDResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='maroon')
	legend("topleft", "m", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	plot(y=MertonJDResults_Jun2016$delta, x=MertonJDResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='blue')
	legend("bottomleft", "delta", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	dev.off()

### Plot Parameter over time w Line
	png("ParameterOverTime_w_Dates.png", width=1200, height=800, pointsize=20)
	
	Dates <- as.POSIXct(c("2016-06-23", "2016-11-08", "2016-12-04"), format="%Y-%m-%d")
	
	id <- NULL
	for(i in 1:(length(Dates))){id <- c(id, max(as.integer(row.names(subset(MertonJDResults, Handelstag<Dates[i], select=Handelstag)))))}
	PreviousDates <- MertonJDResults[id, "Handelstag"]
	
	par(mfrow=c(4,1), mar=c(2, 2, 1.5, 0.1))
	plot(y=MertonJDResults$sigma, x=MertonJDResults$Handelstag, type='b', xlab="", ylab="", col='black')
	legend("topleft", "sigma", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	plot(y=MertonJDResults$lambda, x=MertonJDResults$Handelstag, type='b', xlab="", ylab="", col='green')
	legend("topleft", "lambda", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	plot(y=MertonJDResults$m, x=MertonJDResults$Handelstag, type='b', xlab="", ylab="", col='maroon')
	legend("bottomleft", "m", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	plot(y=MertonJDResults$delta, x=MertonJDResults$Handelstag, type='b', xlab="", ylab="", col='blue')
	legend("topleft", "delta", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	dev.off()

### Plot RSS w Line
	png("RSS_w_Dates.png", width=1000, height=800, pointsize=20)
	par(mfrow=c(1,1), mar=c(2, 2, 1.5, 1))
	plot(y=MertonJDResults$RSS, x=MertonJDResults$Handelstag, type='b', xlab="", ylab="", col='black')
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	dev.off()
	
### Scatterplot with Dates and different colors per day
	png("ParameterScatterplot_w_Dates.png", width=1200, height=800, pointsize=20)
	
	# Set Defaults
	MertonJDResults$color <- "Black"
	MertonJDResults$pch <- 21
	MertonJDResults$cex <- 1
	
	# Set different color...
		MertonJDResults[id, "pch"] <- 15	# Triangle
		MertonJDResults[id + 1, "pch"] <- 17 # Square
		MertonJDResults[id, "cex"] <- 1.5
		MertonJDResults[id + 1, "cex"] <- 1.5
	
		for(i in 1:(length(id))){
			MertonJDResults[id[i], "color"] <- colors[i]
			MertonJDResults[id[i] + 1, "color"] <- colors[i]
		}

	pairs(MertonJDResults[, c("sigma", "lambda", "m", "delta")], col=MertonJDResults$color, pch=MertonJDResults$pch, cex=MertonJDResults$cex)
	dev.off()	
