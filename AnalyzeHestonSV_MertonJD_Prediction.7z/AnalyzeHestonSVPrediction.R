setwd(dirname(rstudioapi::getSourceEditorContext()$path))

### Load & Data cleansing
	HestonSVResults <- read.csv(file="HestonSV_Results.csv")
	HestonSVResults$Handelstag <- as.Date(HestonSVResults$Handelstag, format="%Y-%m-%d")
	
	HestonSVResults$Handelstag <- as.Date(HestonSVResults$Handelstag, format="%Y-%m-%d")
	HestonSVResults$Handelstag <- as.Date(HestonSVResults$Handelstag, format="%Y-%m-%d")

### Plot Parameter Jun 2016 over time w Line
	png("ParameterOverTime_Jun2016.png", width=1200, height=800, pointsize=20)
	
	colors=c("red","purple","turquoise")
	Dates <- as.Date("2016-06-23", format="%Y-%m-%d")
	PreviousDates <- HestonSVResults[max(as.integer(row.names(subset(HestonSVResults, Handelstag<Dates, select=Handelstag)))), "Handelstag"]
	HestonSVResults_Jun2016 <- subset(HestonSVResults, format(HestonSVResults$Handelstag, "%m")=="06")
	
	par(mfrow=c(5,1), mar=c(2, 2, 0.5, 0.1))
	plot(y=HestonSVResults_Jun2016$v0, x=HestonSVResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='black')
	legend("topleft", "v0", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	plot(y=HestonSVResults_Jun2016$vT, x=HestonSVResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='green')
	legend("bottomleft", "vT", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	plot(y=HestonSVResults_Jun2016$rho, x=HestonSVResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='maroon')
	legend("bottomleft", "rho", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	plot(y=HestonSVResults_Jun2016$k, x=HestonSVResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='blue')
	legend("topleft", "k", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	plot(y=HestonSVResults_Jun2016$sigma, x=HestonSVResults_Jun2016$Handelstag, type='b', xlab="", ylab="", col='orange')
	legend("topleft", "sigma", cex=1.5, bty="n")
	abline(v=Dates, col=colors[1], lty=1, lwd=3)
	abline(v=PreviousDates, col=colors[1], lty=2, lwd=3)
	dev.off()

### Plot Parameter over time w Line
	png("ParameterOverTime_w_Dates.png", width=1200, height=800, pointsize=20)
	
	Dates <- as.Date(c("2016-06-23", "2016-11-08", "2016-12-04"), format="%Y-%m-%d")
	
	id <- NULL
	for(i in 1:(length(Dates))){id <- c(id, max(as.integer(row.names(subset(HestonSVResults, Handelstag<Dates[i], select=Handelstag)))))}
	PreviousDates <- HestonSVResults[id, "Handelstag"]
	
	par(mfrow=c(5,1), mar=c(1.75, 2, 0.5, 0.1))
	plot(y=HestonSVResults$v0, x=HestonSVResults$Handelstag, type='b', xlab="", ylab="", col='black')
	legend("topleft", "v0", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	plot(y=HestonSVResults$vT, x=HestonSVResults$Handelstag, type='b', xlab="", ylab="", col='green')
	legend("topleft", "vT", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	plot(y=HestonSVResults$rho, x=HestonSVResults$Handelstag, type='b', xlab="", ylab="", col='maroon')
	legend("bottomleft", "rho", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	plot(y=HestonSVResults$k, x=HestonSVResults$Handelstag, type='b', xlab="", ylab="", col='blue')
	legend("topleft", "k", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	plot(y=HestonSVResults$sigma, x=HestonSVResults$Handelstag, type='b', xlab="", ylab="", col='orange')
	legend("topleft", "sigma", cex=1.5, bty="n")
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	dev.off()

### Plot RSS w Line
	png("RSS_w_Dates.png", width=800, height=600, pointsize=20)
	par(mfrow=c(1,1), mar=c(2, 2, 0.5, 0.5))
	plot(y=HestonSVResults$RSS, x=HestonSVResults$Handelstag, type='b', xlab="", ylab="", col='black')
	abline(v=Dates, col=colors, lty=1, lwd=2)
	abline(v=PreviousDates, col=colors, lty=2, lwd=2)
	dev.off()
	
### Scatterplot with Dates and different colors per day
	png("ParameterScatterplot_w_Dates.png", width=1200, height=800, pointsize=20)
	
	# Set Defaults
	HestonSVResults$color <- "Black"
	HestonSVResults$pch <- 21
	HestonSVResults$cex <- 1
	
	# Set different color...
		HestonSVResults[id, "pch"] <- 15	# Triangle
		HestonSVResults[id + 1, "pch"] <- 17 # Square
		HestonSVResults[id, "cex"] <- 1.5
		HestonSVResults[id + 1, "cex"] <- 1.5
	
		for(i in 1:(length(id))){
			HestonSVResults[id[i], "color"] <- colors[i]
			HestonSVResults[id[i] + 1, "color"] <- colors[i]
		}

	pairs(HestonSVResults[, c("v0", "vT", "rho", "k", "sigma")], col=HestonSVResults$color, pch=HestonSVResults$pch, cex=HestonSVResults$cex)
	dev.off()	
