library(kernlab)
library(e1071)

# Load data
load(file="HestonSV_Results_All.rdata")

library(lubridate)
HestonSVResults_All_julia$Handelstag <- force_tz(HestonSVResults_All_julia$Handelstag, "UTC")

# Create tbds/results
results <- rbind(
  data.frame(expand.grid(
    Kernel = c("sigmoid", "tanhdot"),
    gamma=as.vector(c(1, 2, 5) %*% t(10^(-1:3))),
    coef0=c(0, as.vector(c(-5, -2, -1, 1, 2, 5) %*% t(10^(-1:3)))),
    nu = c(0.01, 0.025, 0.05)
  )),
  data.frame(expand.grid(
    Kernel = c("radial", "rbfdot"),
    gamma = as.vector(c(1, 2, 5) %*% t(10^(-1:3))),
    coef0 = NA,
    nu = c(0.01, 0.025, 0.05)
  ))
)

### SVMs
results_Days <- data.frame(i=integer(), Days=as.Date(character()))
HestonSV_Data <- HestonSVResults_All_julia[c("v0", "vT", "rho", "k", "sigma")]

for(i in 1:nrow(results)){
  print(paste(Sys.time(), " : ", i ,sep=""))
  
  if(results$Kernel[i]=="radial"){ svm_model <- svm(HestonSV_Data, type="one-classification", kernel="radial", gamma=results$gamma[i], nu=results$nu[i], scaled=TRUE) }
  if(results$Kernel[i]=="sigmoid"){ svm_model <- svm(HestonSV_Data, type="one-classification", kernel="sigmoid", gamma=results$gamma[i], coef0=results$coef0[i], nu=results$nu[i], scaled=TRUE) }
  if(results$Kernel[i]=="rbfdot"){ svm_model <- ksvm(as.matrix(HestonSV_Data), type="one-svc", kernel="rbfdot", kpar=list(sigma=results$gamma[i]), nu=results$nu[i], scaled=TRUE) }
  if(results$Kernel[i]=="tanhdot"){ svm_model <- ksvm(as.matrix(HestonSV_Data), type="one-svc", kernel="tanhdot", kpar=list(scale=results$gamma[i], offset=results$coef0[i]), nu=results$nu[i], scaled=TRUE) }
  
  if(class(svm_model) == "svm"){ svm_model_fitted <- svm_model$fitted }
  if(class(svm_model) == "ksvm"){ svm_model_fitted <- svm_model@fitted }
  
  results$True[i] <- sum(svm_model_fitted)
  results$False[i] <- length(svm_model_fitted) - results$True[i]
  
  if(results$False[i]>0){ results_Days <- rbind(results_Days, data.frame(rep(i, results$False[i]), subset(HestonSVResults_All_julia, !svm_model_fitted)$Handelstag)) }
}

colnames(results_Days) <- c("i", "Handelstag")
results$i <- as.numeric(rownames(results))

results_w_Days <- merge(results, results_Days, by="i")

### Deltas
library(arsenal)

for(i in 1:nrow(results)){
  if(results$Kernel[i]=="sigmoid"){
    e1071_days <- results_w_Days[which(results_w_Days$Kernel==results$Kernel[i] & results_w_Days$gamma==results$gamma[i] & results_w_Days$coef0==results$coef0[i] & results_w_Days$nu==results$nu[i]),]
    kernlab_days <- results_w_Days[which(results_w_Days$Kernel=="tanhdot" & results_w_Days$gamma==results$gamma[i] & results_w_Days$coef0==results$coef0[i] & results_w_Days$nu==results$nu[i]),]
  }
  
  if(results$Kernel[i]=="radial"){
    e1071_days <- results_w_Days[which(results_w_Days$Kernel==results$Kernel[i] & results_w_Days$gamma==results$gamma[i] & results_w_Days$nu==results$nu[i]),]
    kernlab_days <- results_w_Days[which(results_w_Days$Kernel=="rbfdot" & results_w_Days$gamma==results$gamma[i] & results_w_Days$nu==results$nu[i]),]
  }
  
  if(results$Kernel[i]=="sigmoid" || results$Kernel[i]=="radial"){
    # Search deltas
      diff <- merge(x=e1071_days[, c("Handelstag","Kernel")], y=kernlab_days[, c("Handelstag","Kernel")], by="Handelstag", all=TRUE)
      colnames(diff) <- c("Handelstag", "e1071", "kernlab")
      diff <- diff[which(is.na(diff$e1071) | is.na(diff$kernlab)),]
      
    if(nrow(diff) > 0) {
      print(results[i,])
      print(diff)
    }
  }
}