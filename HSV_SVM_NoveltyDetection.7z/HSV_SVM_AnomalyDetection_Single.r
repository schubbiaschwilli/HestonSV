library(kernlab)
library(e1071)

# Load & select data
load(file="HestonSV_Results_All.rdata")
HestonSV_Data <- HestonSVResults_All_julia[c("v0", "vT", "rho", "k", "sigma")]

# Set nu
nu <- 0.025

# Build SVM - Select one
svm_model <- svm(HestonSV_Data, type="one-classification", kernel="radial", nu=nu, scaled=TRUE)
#svm_model <- svm(HestonSV_Data, type="one-classification", kernel="sigmoid", nu=nu, scaled=TRUE)
#svm_model <- ksvm(as.matrix(HestonSV_Data), type="one-svc", kernel="rbfdot", kpar="automatic", nu=nu, scaled=TRUE)
#svm_model <- ksvm(as.matrix(HestonSV_Data), type="one-svc", kernel="tanhdot", kpar="automatic", nu=nu, scaled=TRUE)

# Select & Format Outlier
if(class(svm_model) == "svm"){ model_fitted <- svm_model$fitted }
if(class(svm_model) == "ksvm"){ model_fitted <- svm_model@fitted }
Dates <- subset(HestonSVResults_All_julia, !model_fitted)$Handelstag
HestonSVResults_All_julia$Color <- ifelse(model_fitted,"grey","red")

# Create scatterplot
pairs(HestonSV_Data, col=HestonSVResults_All_julia$Color)

# Create Timeseries
par(mfrow=c(5,1), mar=c(1.9, 2, 1.5, 0.1))

plot(y=HestonSVResults_All_julia$v0, x=HestonSVResults_All_julia$Handelstag, type='b', xlab="", ylab="", col='black')
legend("topleft", "v0", cex=1.5, bty="n")
abline(v=Dates, col="red", lty=2)
plot(y=HestonSVResults_All_julia$vT, x=HestonSVResults_All_julia$Handelstag, type='b', xlab="", ylab="", col='green')
legend("topleft", "vT", cex=1.5, bty="n")
abline(v=Dates, col="red", lty=2)
plot(y=HestonSVResults_All_julia$rho, x=HestonSVResults_All_julia$Handelstag, type='b', xlab="", ylab="", col='maroon')
legend("bottomleft", "rho", cex=1.5, bty="n")
abline(v=Dates, col="red", lty=2)
plot(y=HestonSVResults_All_julia$k, x=HestonSVResults_All_julia$Handelstag, type='b', xlab="", ylab="", col='blue')
legend("topleft", "k", cex=1.5, bty="n")
abline(v=Dates, col="red", lty=2)
plot(y=HestonSVResults_All_julia$sigma, x=HestonSVResults_All_julia$Handelstag, type='b', xlab="", ylab="", col='orange')
legend("topleft", "sigma", cex=1.5, bty="n")
abline(v=Dates, col="red", lty=2)
